This is dummy handler Server
To run this do
 
yarn install
then 
yarn serve 

To test sending messages edit 
/src/sendtext.ts

then
yarn install
then
yarn send
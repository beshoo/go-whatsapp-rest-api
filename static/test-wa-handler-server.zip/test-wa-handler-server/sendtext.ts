import request from "request-promise-native";
// const numbers = ["918108742102", "918097716454", "919766745893"];
const numbers = ["918097716454", "919766745893"];
const baseUrl = "http://localhost:3000/api";

function sendTextMulti() {
  let textSendUrl = baseUrl + "/send/text";
  let sessionId = "2e015e72-56ab-4cd6-b431-beb682e3c52c";
  let text = `800 message for every one count`;

  for (let phoneNumber of numbers) {
    let numberReplyIds: any = [];
    for (let i = 0; i < 1000; i++) {
      numberReplyIds.push({
        number: phoneNumber
      });
    }

    let msgBody = {
      sessionId,
      text,
      numberReplyIds
    };

    let options = {
      method: "POST",
      uri: textSendUrl,
      json: true,
      body: msgBody
    };
    request(options);
  }
}

function sendText() {
  let textSendUrl = baseUrl + "/send/text";
  let sessionId = "8b81fab4-51bf-4606-95d0-46642f07629a";
  let text = `300 message for every one count`;
  let numberReplyIds: any = [];

  for (let phoneNumber of numbers) {
    for (let i = 0; i < 300; i++) {
      numberReplyIds.push({
        number: phoneNumber
      });
    }
  }

  let msgBody = {
    sessionId,
    text,
    numberReplyIds
  };

  console.log(JSON.stringify(msgBody));

  let options = {
    method: "POST",
    uri: textSendUrl,
    json: true,
    body: msgBody
  };
  request(options);
}

// sendText();
sendTextMulti();

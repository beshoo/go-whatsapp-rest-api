import express from "express";
import bodyParser from "body-parser";
import multer from "multer";
import path from "path";

const app = express();
const PORT = 3001;

const upload = multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, "../uploaded_images"),
    filename: function(req, file, cb) {
      cb(null, Date.now() + "_" + file.originalname);
    }
  })
});

app.use(
  bodyParser.urlencoded({
    extended: false
  })
);
app.use(bodyParser.json());

app.post("/message/text", async (req, res) => {
  console.log("======= Text =====");
  console.log(req.body);
  res.status(200).send("ok");
});

let imageUpload = upload.fields([
  {
    name: "thumbnail",
    maxCount: 1
  },
  {
    name: "image",
    maxCount: 1
  }
]);
app.post("/message/image", async (req, res) => {
  console.log("======= Image =====");
  console.log(req.body);
  res.status(200).send("ok");
});

let videoUpload = upload.fields([
  {
    name: "thumbnail",
    maxCount: 1
  },
  {
    name: "video",
    maxCount: 1
  }
]);
app.post("/message/video", async (req, res) => {
  console.log("======= Video =====");
  console.log(req.body);
  res.status(200).send("ok");
});

app.post("/message/audio", async (req, res) => {
  console.log("======= Audio =====");
  console.log(req.body);
  res.status(200).send("ok");
});

app.post("/message/doc", async (req, res) => {
  console.log("======= Video =====");
  console.log(req.body);
  res.status(200).send("ok");
});

app.post("/message/contact", async (req, res) => {
  console.log("======= Contact =====");
  console.log(req.body);
  res.status(200).send("ok");
});

app.post("/message/location", async (req, res) => {
  console.log("======= Location =====");
  console.log(req.body);
  res.status(200).send("ok");
});

app.post("/message/livelocation", async (req, res) => {
  console.log("=======Live Location =====");
  console.log(req.body);
  res.status(200).send("ok");
});

app.post("/notify/logout", async (req, res) => {
  console.log("=======Logout =====");
  console.log(req.body);
  res.status(200).send("ok");
});

app.post("/notify/connectivity", async (req, res) => {
  console.log("=======Connectivity =====");
  console.log(req.body);
  res.status(200).send("ok");
});

app.listen(PORT, () => console.log(`Bot running on ${PORT}!`));

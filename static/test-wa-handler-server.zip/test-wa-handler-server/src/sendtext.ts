import request from "request-promise-native";

const numbers = ["918090980303"];
const baseUrl = "http://localhost:3000/api";

function sendTextMulti() {
  let textSendUrl = baseUrl + "/send/text";
  // let sessionId = "ce16bbbb-bb96-4dc1-84f0-474e7b14219b"; // replace session id with session ID of the number
  let sessionId = "2b7fda23-c398-4194-86f2-77859901b15f"; // replace session id with session ID of the number
  let text = `1500 message for every one count`; // the message
  let count = 1500; // number of messages to eahc persion

  for (let phoneNumber of numbers) {
    let numberReplyIds: any = [];
    for (let i = 0; i < count; i++) {
      numberReplyIds.push({
        number: phoneNumber
      });
    }

    let msgBody = {
      sessionId,
      text,
      numberReplyIds
    };

    let options = {
      method: "POST",
      uri: textSendUrl,
      json: true,
      body: msgBody
    };
    request(options);
  }
}

function sendText() {
  let textSendUrl = baseUrl + "/send/text";
  let sessionId = "8b81fab4-51bf-4606-95d0-46642f07629a";
  let text = `300 message for every one count`;
  let numberReplyIds: any = [];

  for (let phoneNumber of numbers) {
    for (let i = 0; i < 300; i++) {
      numberReplyIds.push({
        number: phoneNumber
      });
    }
  }

  let msgBody = {
    sessionId,
    text,
    numberReplyIds
  };

  console.log(JSON.stringify(msgBody));

  let options = {
    method: "POST",
    uri: textSendUrl,
    json: true,
    body: msgBody
  };
  request(options);
}

// sendText();
sendTextMulti();
